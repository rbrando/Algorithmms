##Python 3.7.3 Implementation
import math

## Create a max heap from an unsorted array
def build_max_heap(array):
    # Build Up the Max Heap
    floor = math.floor(len(array)/2)
    for i in range(floor, -1, -1):
        heapify(array,len(array), i)

## Similar to buil-max-heap, but assumes partof array is already sorted
def heapify(array, length, index):
    left = (2 * index) + 1 ## Gives the left side of the parent node
    right = (2 * index) + 2 ## Gives the right side of the parent node

    maxNum = index

    # Check left side of the heap for the max number
    if (left < length) and (array[left] > array[index]):
        maxNum = left

    # Check right side of the heap for the max number
    if (right < length) and (array[right] > array[maxNum]):
        maxNum = right

    if (maxNum != index):
        array[index], array[maxNum] = array[maxNum], array[index]
        heapify(array, length, maxNum)


# def validate_tree(array):
#     # Prints the heap in a tree visual format
#
#     print("\t" + str(array[0]))
#     print("     " + str(array[1]) + "     " + str(array[2]))
#     print(" " + str(array[3]) + "\t" + str(array[4]) + "\t" + str(array[5]))
#     print("Prints the heap in a tree visual format")

###################
#- Collect input -#
###################
def get_input():
    ## Get inputs, and store them in an array
    numWordsInCase = input()
    rawArray = []
    for i in range(0,int(numWordsInCase)):
        rawArray.append(input())
    return rawArray

###################
#- Print Results -#
###################
def print_results(array):
    ## Print out the entire array
    for i in range(0,len(array)):
        for j in range(0,len(array[i])):
            print(array[i][j])

###############
#- Heap Sort -#
###############
# 1. Create max heap from regular array/heap.
# 2. Remove largest item.
#    - Remove largest item and swap it with the atem at the end o the array
# 3. Place item in sorted partition.
#    - Remove it from the unsorted array.
# 4. Rerun heapify on unsorted heap.
# 5. Repeat from step 1.

def heap_sort(array):
    build_max_heap(array)

    length = len(array) - 1
    for i in range(length, 0, -1):
        array[i],array[0] = array[0], array[i]
        heapify(array, i, 0)

##########
#- Main -#
##########
def main():
    numTestCases = input()

    sorted = []
    for i in range(0,int(numTestCases)):
        ## Get Input returns the input as an array
        array = get_input()
        heap_sort(array)
        sorted.append(array)
    print_results(sorted)

main()
